import { v4 } from "uuid";

export class IdGenerator {

    public generateId = () => v4() 
}